--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE admin;
ALTER ROLE admin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:zg5P3QgPsKkLoggQUTlbww==$NMdEFGU1VVVH22dCSpAstLqWx0jdJSj2A7fonvP+OVU=:mx3tQotV5Cb930UdLzlKsID/b/iFP+kEC5SBOwITnVk=';
CREATE ROLE api;
ALTER ROLE api WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:uru+g5m6KoyqjMfp28LDzA==$rZc7Tv0aRrKBnC3N58m0zigZ8awcrlSGqHyX2hSj6AI=:/yC7jjUJHV+cYyF50MqHWXDCbJwPUTDOCX5BBKuTQW4=';

--
-- User Configurations
--








--
-- PostgreSQL database cluster dump complete
--

